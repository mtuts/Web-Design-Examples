      <div class="footer">
        <p>All Rights &copy; Reserved 2016</p>
      </div>
    </div>

      <script type="text/javascript" src="<?php echo $data['base']; ?>/js/script.js"></script>
  </body>
</html>
